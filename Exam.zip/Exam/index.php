<!DOCTYPE html>
<html lang="en">
    

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/stylec.css">
</head>

<body>
    
    <div class="headerr">
        <div class="header_left">
            <img src="examportal/logo.png" alt="">
            <img class="left_cor" src="examportal/leftcollege.PNG" alt="">
        </div>
        <center>
        <div class="header_middle">
            <h1>G.H Raisoni Institute Of Engineering and Technology,pune</h1>
            <h4>An Autonomous Institute, Affiliated to Savitribai Phule Pune University</h4>
            <h4>Approved by AICTE, New Delhi and Recognized By Govt. Of Maharashtra <br>NAAC Accredited</h4>
            <h2>DTE Code : 6155</h2>
        </div>
        <div class="header_wel">
            <h3>
                <marquee width="60%" direction="left" height="100px">Welcome To G.H Raisoni college of engineeing an technology's Exam Portal</marquee>
            </h3>

        </div>
        </center>
        <div class="header_down">
        <div class="btn">
            <button class="btn success">home</button>
            <div class="space"></div>
            <button class="btn info">Events</button>
            <div class="space"></div>
            <button class="btn danger">Student section</button>
            <div class="space"></div>
            <button class="btn default">Staff section</button>
            <div class="space"></div>
            <button class="btn default">Department</button>
            <div class="space"></div>
            <button class="btn default">Exam Rules</button>
            <div class="space"></div>
            <button class="btn default" onclick="window.location.href='/contact.html'">Contact</button>
            <div class="space"></div>
            <div class="space"></div>
            <div class="space"></div>

            <a href="/exam/logins.php" onclick="removeday()" class="logbtn">login</a>
    </div>
    <!-- second header -->
    <!-- <div class="header_down">
        <div class="btn">
            <button class="btn success">home</button>
            <div class="space"></div>
            <button class="btn info">Events</button>
            <div class="space"></div>
            <button class="btn danger">Student section</button>
            <div class="space"></div>
            <button class="btn default">Staff section</button>
            <div class="space"></div>
            <button class="btn default">Department</button>
            <div class="space"></div>
            <button class="btn default">Exam Rules</button>
            <div class="space"></div>
            <button class="btn default" onclick="window.location.href='/contact.html'">Contact</button>
            <div class="space"></div>
            <div class="space"></div>
            <div class="space"></div>

            <a href="/exam/logins.php" onclick="removeday()" class="logbtn">login</a>
         -->


            <!-- apna login button -->

        <!-- </div> -->


    
    </div>
    <div class="middlet">
        <h2>ABOUT GHRCEM PUNE </h2>
        <h3>"Education must not simply teach work - it must teach life"</h3>
        <em> - Anonymous </em>
        <div class="middlepara">
            The G H Raisoni College of Engineering and Management is affiliated to the Savitribai Phule University. <br>It is an autonomous institute and is approved by the All India Council for Technical Education (AICTE). <br> We at the G H Raisoni
            College of Engineering and Management, Wagholi, <br><br>Pune imbibe and impart the same as an indispensable aspect of our education system.<br> We disseminate quality education and continue to practice excellence as our core facet.<br>We harbor
            the finest amenities to ensure the best learning paradigm for our students of Engineering and Management branch.
        </div>
    </div>
    <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #FC7E7E;
  color: white;
  text-align: center;
  height: 170px;
}
</style>

<div class="footer">
  <h2>Developer:Akash Shinde & Team</h2>
  <h4>Akash Shinde Roll no:-56</h4>
  <h4>krushna shinde Roll no:-57</h4>
  <h4>Hanumant Karhale Roll no:-22</h4>
  <h4>Sudershan bhosle Roll no:-7</h4>


</div>
</body>
</html>